This is a template for the PhD confirmation report at School of Computing and Information Systems, The University of Melbourne. You can directly use this template via overleaf, https://www.overleaf.com/latex/templates/university-of-melbourne-phd-confirmation-report-template/ztwzbrfkggcv.

It is just the template I used for confirmation report, not an official one. If you are going to write a confirmation report, please feel free to use it. I believe that it is easy to adapt this template to other kinds of reports.

I developed this based on the styles from https://github.com/kourgeorge/arxiv-style. Thanks for their contributions.

You can get the updated version of this template at https://github.com/oaimli/ConfirmationReportTemplate. If you have any more suggestions about this template, please tell me to update.

